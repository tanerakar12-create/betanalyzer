// ============================================================
// Netlify Serverless Function — TheSportsDB Proxy
// CORS sorununu tamamen ortadan kaldırır.
// Endpoint: /.netlify/functions/proxy?d=2026-04-14&l=4328
// ============================================================

exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
    "Cache-Control": "public, max-age=120" // 2 dk cache
  };

  // OPTIONS preflight
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }

  const qs = event.queryStringParameters || {};
  const d = qs.d; // tarih: 2026-04-14
  const l = qs.l; // lig id: 4328

  if (!d || !l) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: "d (date) ve l (league) parametreleri gerekli" })
    };
  }

  // TheSportsDB free API — key=3 ücretsiz, sınırsız
  const url = `https://www.thesportsdb.com/api/v1/json/3/eventsday.php?d=${d}&l=${l}`;

  try {
    const res = await fetch(url, {
      headers: { "User-Agent": "BetAnalyzer/1.0" },
      signal: AbortSignal.timeout(8000)
    });

    if (!res.ok) {
      throw new Error(`TheSportsDB HTTP ${res.status}`);
    }

    const data = await res.json();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(data)
    };
  } catch (err) {
    console.error("Proxy error:", err.message);

    // football-data.org free tier backup
    try {
      const fbUrl = `https://api.football-data.org/v4/matches?dateFrom=${d}&dateTo=${d}`;
      const fbRes = await fetch(fbUrl, {
        headers: { "X-Auth-Token": "test" }, // free tier works without valid token for some endpoints
        signal: AbortSignal.timeout(6000)
      });
      if (fbRes.ok) {
        const fbData = await fbRes.json();
        return { statusCode: 200, headers, body: JSON.stringify({ events: null, _fallback: true, _footballdata: fbData }) };
      }
    } catch (e2) { /* ignore */ }

    return {
      statusCode: 502,
      headers,
      body: JSON.stringify({ error: err.message, events: null })
    };
  }
};
