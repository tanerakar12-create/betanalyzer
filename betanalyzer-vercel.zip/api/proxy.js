// Vercel Serverless Function — TheSportsDB Proxy
// Endpoint: /api/proxy?d=2026-04-14&l=4328

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Cache-Control', 'public, max-age=120');

  if (req.method === 'OPTIONS') return res.status(204).end();

  const { d, l } = req.query;
  if (!d || !l) return res.status(400).json({ error: 'd ve l parametreleri gerekli' });

  const url = `https://www.thesportsdb.com/api/v1/json/3/eventsday.php?d=${d}&l=${l}`;

  try {
    const r = await fetch(url, {
      headers: { 'User-Agent': 'BetAnalyzer/1.0' }
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const data = await r.json();
    return res.status(200).json(data);
  } catch (err) {
    return res.status(502).json({ error: err.message, events: null });
  }
}
